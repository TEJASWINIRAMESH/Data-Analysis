import numpy as np
import matplotlib.pyplot as plt
import cv2
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.utils import to_categorical

# Function to convert an image to a binary grid
def image_to_binary_grid(image_path, grid_size=(20, 20), threshold_ratio=0.5):
    # Load the image in grayscale
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    # Resize the image to the specified grid size
    resized_image = cv2.resize(image, grid_size, interpolation=cv2.INTER_AREA)
    
    # Normalize the image (optional, but helps in setting a consistent threshold)
    normalized_image = resized_image / 255.0
    
    # Calculate the threshold based on the mean pixel value
    threshold = threshold_ratio * np.max(normalized_image)
    
    # Convert to binary grid: 1 if pixel value > threshold, else 0
    binary_grid = (normalized_image > threshold).astype(int)
    
    return binary_grid

# Function to load dataset and convert images to binary grids
def load_dataset(data_dir, grid_size=(20, 20)):
    labels = {'circle': 0, 'square': 1, 'triangle': 2}
    data = []
    target = []
    
    for label in labels.keys():
        class_dir = os.path.join(data_dir, label)
        for filename in os.listdir(class_dir):
            if filename.endswith('.png'):
                image_path = os.path.join(class_dir, filename)
                binary_grid = image_to_binary_grid(image_path, grid_size)
                data.append(binary_grid.flatten())
                target.append(labels[label])
                
    data = np.array(data)
    target = np.array(target)
    
    return data, target

# Load and preprocess the dataset
data_dir = r'D:\6TH SEM\bio optimized\shapes\data'  # Replace with the actual path to your dataset
data, target = load_dataset(data_dir, grid_size=(20, 20))
data = data.astype('float32')
target = to_categorical(target, num_classes=3)

# Split the dataset into training and validation sets
x_train, x_val, y_train, y_val = train_test_split(data, target, test_size=0.2, random_state=42)

# Build the Neural Network Model
model = Sequential([
    Dense(64, input_dim=400, activation='relu'),
    Dense(64, activation='relu'),
    Dense(3, activation='softmax')  # 3 classes: Circle, Square, Triangle
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(x_train, y_train, epochs=1000, batch_size=32, validation_data=(x_val, y_val))

# Evaluate the Model
val_loss, val_acc = model.evaluate(x_val, y_val)
print(f'Validation accuracy: {val_acc * 100:.2f}%')

# # Plot training & validation accuracy values
# plt.plot(history.history['accuracy'])
# plt.plot(history.history['val_accuracy'])
# plt.title('Model accuracy')
# plt.ylabel('Accuracy')
# plt.xlabel('Epoch')
# plt.legend(['Train', 'Validation'], loc='upper left')
# plt.show()

# # Plot training & validation loss values
# plt.plot(history.history['loss'])
# plt.plot(history.history['val_loss'])
# plt.title('Model loss')
# plt.ylabel('Loss')
# plt.xlabel('Epoch')
# plt.legend(['Train', 'Validation'], loc='upper left')
# plt.show()

# Predict on New Images
def predict_image(image_path):
    # Convert the image to a binary grid
    binary_grid = image_to_binary_grid(image_path, grid_size=(20, 20)).flatten().astype('float32')
    binary_grid = np.expand_dims(binary_grid, axis=0)  # Add batch dimension
    
    # Predict the class
    prediction = model.predict(binary_grid)
    class_idx = np.argmax(prediction)
    
    # Map class index to class name
    class_names = {0: 'Circle', 1: 'Square', 2: 'Triangle'}
    predicted_class = class_names[class_idx]
    
    print(f'The shape is a {predicted_class}')

# Example usage
image_path = r'D:\6TH SEM\bio optimized\shapes\data\square\Screenshot 2024-05-24 222913.png'  # Replace with the actual path to your image
predict_image(image_path)
